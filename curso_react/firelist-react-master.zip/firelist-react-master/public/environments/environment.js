const environment = {
  firebase: {
    apiKey: 'AIzaSyBJ4DGhjq1TokIj7UrVMuUCqdAXO3g_FAs',
    authDomain: 'firelist-react.firebaseapp.com',
    databaseURL: 'https://firelist-react.firebaseio.com',
    projectId: 'firelist-react',
    storageBucket: 'firelist-react.appspot.com',
    messagingSenderId: '408807346380',
  },
  firebaseRoot: 'production',
  uploadPath: 'firelist-react/uploads',
};
