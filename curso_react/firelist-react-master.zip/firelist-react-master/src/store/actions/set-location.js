export default (state, location) => {
  return { location, drawerOpen: false };
};
