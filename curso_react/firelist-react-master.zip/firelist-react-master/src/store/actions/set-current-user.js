export default (state, currentUser) => {
  return { currentUser };
};
