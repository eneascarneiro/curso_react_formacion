export default (state, notes = []) => {
  return { notes };
};
