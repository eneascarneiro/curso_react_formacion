export default (state, messagingToken) => {
  return { messagingToken };
};
