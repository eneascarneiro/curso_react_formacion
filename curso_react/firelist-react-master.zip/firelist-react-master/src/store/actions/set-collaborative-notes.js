export default (state, collaborativeNotes = []) => {
  return { collaborativeNotes };
};
