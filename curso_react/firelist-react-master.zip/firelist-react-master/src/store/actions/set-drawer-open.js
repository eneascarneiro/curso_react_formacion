export default (state, drawerOpen) => {
  return { drawerOpen };
};
