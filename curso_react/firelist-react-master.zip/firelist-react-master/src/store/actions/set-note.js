export default (state, note = null) => {
  return { note };
};
