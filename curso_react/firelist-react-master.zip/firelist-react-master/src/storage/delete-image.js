/* globals firebase */
const storage = firebase.storage();

export default name => {
  /* 
    CHALLENGE Storage
    - See https://firebase.google.com/docs/storage/web/delete-files
    - Create a reference to the image using `name`
    - Delete the image
  */
  return storage.ref(name).delete();
};
