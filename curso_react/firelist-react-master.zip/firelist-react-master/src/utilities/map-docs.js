import formatDoc from './format-doc';

export default function mapDocs(docs) {
  return docs.map(formatDoc);
}
