export default email => email.toLowerCase().replace(/[^a-zA-Z]/g, '|');
