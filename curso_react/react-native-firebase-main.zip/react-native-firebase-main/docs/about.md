---
title: About
description: This history and future of React Native Firebase
noindex: true
---

# About React Native Firebase

The React Native Firebase project started life in late 2016 as a personal project [Mike Diarmid](https://twitter.com/mikediarmid)
and [Elliot Hesp](https://twitter.com/elliothesp) were working on. The project gained instant popularity, allowing React Native developers
to hook into the native services Firebase provides.

During the first few months of its development, the repository was moved into the organization of Invertase on GitHub.
The organization was a collection of the personal and combined Open Source efforts Mike and Elliot had been
working over the past number of years. With a constant flow of feature requests, issues and contributions,
the library rapidly grew in popularity, achieving over 100k NPM downloads in its first 12 months of development.

In mid-2017, we were approached by Google, who offered to help ensure the projects continued support by providing direct contact with the
Firebase team and by providing funding to ensure the project had dedicated time assigned to its upkeep.

In the 2018 Firebase Summit in Prague during the opening keynote, Google openly announced their
working relationship with Invertase - check it out below:

[https://twitter.com/rnfirebase/status/1056839638961348608/video/1](https://twitter.com/rnfirebase/status/1056839638961348608/video/1)

## Future of the library

The React Native Firebase library has been a huge driving force for our knowledge and experience. Even with years of
experience in Open Source, JavaScript, Android and iOS, we're constantly learning and improving the library -
whilst focusing on the needs of the community and many users of the library. Maintaining a popular Open Source
library is hard, yet rewarding work.

With the support from the community and Google, we're pleased to announce that starting in 2019, our very own
Mike Diarmid will be working full time on the library. With the lessons we've learnt, we'll be focusing on taking the
library to a new level. Read about it [here](https://invertase.io/blog/react-native-firebase-2019).

The success and upkeep of the library would not be possible without the support and contributions from the community.
To date, we've had contributions from 114 members of the Open Source community on the repository to who we're very
grateful to, the project wouldn't be where it is without you. Special thanks to Chris Bianca
at [CS Frequency Limited](http://invertase.link/csf-website) for their work in helping to get this project off the ground.

We'd also like to extend our thanks to our backers on Open Collective, whose contributions have made it possible to
sustain the vast amount of time required in the upkeep of such a project.

The future of Invertase and React Native Firebase is exciting.
