module.exports = require('./tests/metro.config');
