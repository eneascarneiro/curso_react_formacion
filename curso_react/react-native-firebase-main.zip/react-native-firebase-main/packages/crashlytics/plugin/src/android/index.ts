import { withApplyCrashlyticsPlugin } from './applyPlugin';
import { withBuildscriptDependency } from './buildscriptDependency';

export { withBuildscriptDependency, withApplyCrashlyticsPlugin };
