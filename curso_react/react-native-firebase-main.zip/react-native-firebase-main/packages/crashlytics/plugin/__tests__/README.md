Please see the `packages/app/plugin/__tests__/README.md`.
