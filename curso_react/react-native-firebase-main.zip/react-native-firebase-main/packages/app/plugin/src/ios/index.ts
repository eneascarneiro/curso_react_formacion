import { withFirebaseAppDelegate } from './appDelegate';
import { withIosGoogleServicesFile } from './googleServicesPlist';

export { withIosGoogleServicesFile, withFirebaseAppDelegate };
