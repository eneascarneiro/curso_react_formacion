module.exports = {
  arrowParens: 'avoid',
  trailingComma: 'all',
  useTabs: false,
  semi: true,
  singleQuote: true,
  bracketSpacing: true,
  bracketSameLine: false,
  tabWidth: 2,
  printWidth: 100,
};
