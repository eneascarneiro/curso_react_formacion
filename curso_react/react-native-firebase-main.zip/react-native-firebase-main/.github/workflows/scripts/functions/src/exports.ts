/*
 *
 *  Testing tools for invertase/react-native-firebase use only.
 *
 *  Copyright (C) 2018-present Invertase Limited <oss@invertase.io>
 *
 *  See License file for more information.
*/

/* eslint-disable global-require */
module.exports = {
  SAMPLE_DATA: require('./functions/sample-data'),
};
